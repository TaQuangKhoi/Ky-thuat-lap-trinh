﻿using System;
using System.Collections.Generic;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace interface_QLCHVB
{
    interface iVangBac
    {
        double XetGiamGia();
        void TinhTongTien();
        void NhapTTSanPham(ArrayList arrVangBac, int i);
        void XuatTTSanPham();
    }
    
}
